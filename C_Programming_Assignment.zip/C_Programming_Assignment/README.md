# C Programming Assignment

This repository follows the two-folder structure requested in the assignment instructions.

## Folders
- `Platform_Questions/` — Word documents for the 30 online-platform questions. Each document contains a C solution, problem link, and a clearly marked place for the student's genuine successful-submission screenshot.
- `VSCode_Questions/` — 16 complete `.c` programs for the custom pattern-printing questions in Module 7.

## Important before final submission
1. Open each platform question using the link in its Word document.
2. Submit the C solution on the platform while signed in.
3. Capture the genuine Accepted/success screenshot and paste it into the matching Word document.
4. Review each solution against the platform's exact statement and constraints.
5. Upload both folders to the assigned GitHub repository.
6. Paste the repository URL into the college LMS.

Some platform problem statements can vary by version or require a specific input/output format. Verify each statement before submitting.
