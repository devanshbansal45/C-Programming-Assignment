#include <stdio.h>
int main(void) {
    int n, count = 0; scanf("%d", &n);
    for (int i = 1; i * i <= n; i++)
        if (n % i == 0) count += (i * i == n) ? 1 : 2;
    printf("%d\n", count);
    return 0;
}
