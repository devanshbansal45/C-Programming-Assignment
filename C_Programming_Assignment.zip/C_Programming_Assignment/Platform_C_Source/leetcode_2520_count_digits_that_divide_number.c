int countDigits(int num) {
    int x = num, count = 0;
    while (x > 0) { int d = x % 10; if (d != 0 && num % d == 0) count++; x /= 10; }
    return count;
}
