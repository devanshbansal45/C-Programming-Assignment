#include <stdio.h>
int main(void) {
    int a, b; scanf("%d%d", &a, &b);
    char *words[] = {"zero","one","two","three","four","five","six","seven","eight","nine"};
    for (int i = a; i <= b; i++) {
        if (i >= 1 && i <= 9) puts(words[i]);
        else puts(i % 2 == 0 ? "even" : "odd");
    }
    return 0;
}
