int reverse(int x) {
    long rev = 0;
    while (x != 0) {
        rev = rev * 10 + x % 10;
        x /= 10;
        if (rev > 2147483647L || rev < -2147483648L) return 0;
    }
    return (int)rev;
}
