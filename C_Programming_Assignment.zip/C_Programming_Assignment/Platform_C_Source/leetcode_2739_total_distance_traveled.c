int distanceTraveled(int mainTank, int additionalTank) {
    int distance = 0;
    while (mainTank >= 5) {
        int batches = mainTank / 5;
        distance += batches * 50;
        mainTank %= 5;
        int transfer = batches < additionalTank ? batches : additionalTank;
        mainTank += transfer;
        additionalTank -= transfer;
    }
    return distance + mainTank * 10;
}
