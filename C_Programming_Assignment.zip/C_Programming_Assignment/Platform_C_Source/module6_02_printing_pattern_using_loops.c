#include <stdio.h>
int main(void) {
    int n; scanf("%d", &n);
    for (int i = n; i >= 1; i--) {
        for (int j = n; j >= 1; j--) {
            int v = i > j ? i : j;
            printf("%d", v);
        }
        for (int j = 2; j <= n; j++) {
            int v = i > j ? i : j;
            printf("%d", v);
        }
        putchar('\n');
    }
    for (int i = 2; i <= n; i++) {
        for (int j = n; j >= 1; j--) {
            int v = i > j ? i : j;
            printf("%d", v);
        }
        for (int j = 2; j <= n; j++) {
            int v = i > j ? i : j;
            printf("%d", v);
        }
        putchar('\n');
    }
    return 0;
}
